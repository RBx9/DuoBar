#import "RBXAppDelegate.h"
#import "RBXCaptureViewController.h"

@interface RBXAppDelegate ()
@property (nonatomic, strong) RBXCaptureViewController *captureVC;
@end

@implementation RBXAppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)options {
    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    self.captureVC = [RBXCaptureViewController new];
    self.window.rootViewController = self.captureVC;
    [self.window makeKeyAndVisible];
    NSURL *launchURL = options[UIApplicationLaunchOptionsURLKey];
    if (launchURL) [self handleURL:launchURL];
    return YES;
}

- (BOOL)application:(UIApplication *)app openURL:(NSURL *)url options:(NSDictionary<UIApplicationOpenURLOptionsKey,id> *)options {
    return [self handleURL:url];
}

- (BOOL)handleURL:(NSURL *)url {
    if (![[url.scheme lowercaseString] isEqualToString:@"rbx9capture"]) return NO;
    NSString *action = [url.host lowercaseString];
    if ([action isEqualToString:@"photo"]) {
        [self.captureVC requestAction:RBXRequestedActionPhoto];
    } else if ([action isEqualToString:@"video"]) {
        [self.captureVC requestAction:RBXRequestedActionVideo];
    } else return NO;
    return YES;
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    [self.captureVC stopForBackground];
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    [self.captureVC resumeFromBackground];
}
@end
