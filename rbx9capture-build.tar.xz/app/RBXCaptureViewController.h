#import <UIKit/UIKit.h>

typedef NS_ENUM(NSInteger, RBXRequestedAction) {
    RBXRequestedActionNone = 0,
    RBXRequestedActionPhoto = 1,
    RBXRequestedActionVideo = 2
};

@interface RBXCaptureViewController : UIViewController
- (void)requestAction:(RBXRequestedAction)action;
- (void)stopForBackground;
- (void)resumeFromBackground;
@end
