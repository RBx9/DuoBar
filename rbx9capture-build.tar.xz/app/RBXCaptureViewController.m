#import "RBXCaptureViewController.h"
#import <AVFoundation/AVFoundation.h>
#import <Photos/Photos.h>
#import <CoreMedia/CoreMedia.h>

static NSString * const kPositionKey = @"RBXPosition";
static NSString * const kQualityKey = @"RBXQuality";
static NSString * const kFPSKey = @"RBXFPS";

@interface RBXCaptureViewController () <AVCapturePhotoCaptureDelegate, AVCaptureFileOutputRecordingDelegate>
@property (nonatomic, strong) AVCaptureSession *session;
@property (nonatomic, strong) AVCaptureVideoPreviewLayer *preview;
@property (nonatomic, strong) AVCapturePhotoOutput *photoOutput;
@property (nonatomic, strong) AVCaptureMovieFileOutput *movieOutput;
@property (nonatomic, strong) dispatch_queue_t cameraQueue;
@property (nonatomic, strong) UILabel *statusLabel;
@property (nonatomic, strong) UILabel *infoLabel;
@property (nonatomic, strong) UIButton *photoButton;
@property (nonatomic, strong) UIButton *recordButton;
@property (nonatomic, strong) UIButton *flipButton;
@property (nonatomic, strong) UIButton *qualityButton;
@property (nonatomic, strong) UIButton *fpsButton;
@property (nonatomic, assign) BOOL cameraReady;
@property (nonatomic, assign) BOOL isRecording;
@property (nonatomic, assign) BOOL isStopping;
@property (nonatomic, assign) BOOL isBackgrounded;
@property (nonatomic, assign) RBXRequestedAction pendingAction;
@end

@implementation RBXCaptureViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor blackColor];
    [[NSUserDefaults standardUserDefaults] registerDefaults:@{kPositionKey: @NO, kQualityKey: @1, kFPSKey: @30}];
    self.cameraQueue = dispatch_queue_create("com.rbx9.capture.session", DISPATCH_QUEUE_SERIAL);
    self.session = [AVCaptureSession new];
    self.preview = [AVCaptureVideoPreviewLayer layerWithSession:self.session];
    self.preview.videoGravity = AVLayerVideoGravityResizeAspectFill;
    [self.view.layer addSublayer:self.preview];

    self.statusLabel = [self makeLabel:@"CAMERA OFF" size:15];
    self.statusLabel.textAlignment = NSTextAlignmentCenter;
    self.statusLabel.backgroundColor = [UIColor colorWithRed:0.55 green:0.10 blue:0.13 alpha:0.98];
    self.statusLabel.layer.cornerRadius = 14;
    self.statusLabel.clipsToBounds = YES;
    [self.view addSubview:self.statusLabel];

    self.infoLabel = [self makeLabel:@"Camera permission required" size:14];
    self.infoLabel.textAlignment = NSTextAlignmentCenter;
    self.infoLabel.numberOfLines = 3;
    [self.view addSubview:self.infoLabel];

    self.photoButton = [self makeButton:@"PHOTO" action:@selector(takePhotoTapped:)];
    self.recordButton = [self makeButton:@"RECORD" action:@selector(recordTapped:)];
    self.recordButton.backgroundColor = [UIColor colorWithRed:0.79 green:0.14 blue:0.21 alpha:0.98];
    self.flipButton = [self makeButton:@"FLIP" action:@selector(flipTapped:)];
    self.qualityButton = [self makeButton:@"1080p" action:@selector(qualityTapped:)];
    self.fpsButton = [self makeButton:@"30 FPS" action:@selector(fpsTapped:)];
    [self updateSettingsButtons];
    [self updateRecordAppearance];
}

- (UILabel *)makeLabel:(NSString *)text size:(CGFloat)size {
    UILabel *label = [UILabel new];
    label.text = text;
    label.textColor = [UIColor whiteColor];
    label.font = [UIFont systemFontOfSize:size weight:UIFontWeightSemibold];
    return label;
}

- (UIButton *)makeButton:(NSString *)title action:(SEL)selector {
    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    [button setTitle:title forState:UIControlStateNormal];
    [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    button.titleLabel.font = [UIFont systemFontOfSize:16 weight:UIFontWeightBold];
    button.layer.cornerRadius = 16;
    button.backgroundColor = [UIColor colorWithWhite:0.16 alpha:0.92];
    [button addTarget:self action:selector forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button];
    return button;
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    CGRect bounds = self.view.bounds;
    self.preview.frame = bounds;
    CGFloat width = bounds.size.width;
    CGFloat top = self.view.safeAreaInsets.top + 12;
    CGFloat bottom = bounds.size.height - self.view.safeAreaInsets.bottom;
    self.statusLabel.frame = CGRectMake(24, top, width - 48, 42);
    self.infoLabel.frame = CGRectMake(24, top + 52, width - 48, 66);
    self.photoButton.frame = CGRectMake(20, bottom - 90, (width - 52) / 2.0, 64);
    self.recordButton.frame = CGRectMake(32 + (width - 52) / 2.0, bottom - 90, (width - 52) / 2.0, 64);
    self.flipButton.frame = CGRectMake(20, bottom - 154, 84, 46);
    self.qualityButton.frame = CGRectMake(112, bottom - 154, (width - 228) / 2.0, 46);
    self.fpsButton.frame = CGRectMake(120 + (width - 228) / 2.0, bottom - 154, (width - 228) / 2.0, 46);
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [self resumeFromBackground];
}

- (NSString *)desiredPreset {
    NSInteger q = [[NSUserDefaults standardUserDefaults] integerForKey:kQualityKey];
    if (q == 2) return AVCaptureSessionPreset3840x2160;
    if (q == 0) return AVCaptureSessionPreset1280x720;
    return AVCaptureSessionPreset1920x1080;
}

- (NSInteger)desiredFPS {
    return [[NSUserDefaults standardUserDefaults] integerForKey:kFPSKey] == 60 ? 60 : 30;
}

- (AVCaptureDevicePosition)desiredCameraPosition {
    return [[NSUserDefaults standardUserDefaults] boolForKey:kPositionKey] ? AVCaptureDevicePositionFront : AVCaptureDevicePositionBack;
}

- (void)resumeFromBackground {
    self.isBackgrounded = NO;
    AVAuthorizationStatus status = [AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeVideo];
    if (status == AVAuthorizationStatusNotDetermined) {
        [AVCaptureDevice requestAccessForMediaType:AVMediaTypeVideo completionHandler:^(BOOL granted) {
            dispatch_async(dispatch_get_main_queue(), ^{
                if (granted) [self requestMicrophoneAndConfigure];
                else [self showCameraPermissionError];
            });
        }];
    } else if (status == AVAuthorizationStatusAuthorized) {
        [self requestMicrophoneAndConfigure];
    } else {
        [self showCameraPermissionError];
    }
}

- (void)requestMicrophoneAndConfigure {
    AVAuthorizationStatus microphoneStatus = [AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeAudio];
    if (microphoneStatus == AVAuthorizationStatusNotDetermined) {
        [AVCaptureDevice requestAccessForMediaType:AVMediaTypeAudio completionHandler:^(BOOL granted) {
            dispatch_async(dispatch_get_main_queue(), ^{ [self startSession]; });
        }];
    } else {
        [self startSession];
    }
}

- (void)showCameraPermissionError {
    self.infoLabel.text = @"Camera access denied. Allow RBx9 Capture in Settings > Privacy > Camera.";
    self.statusLabel.text = @"CAMERA OFF";
}

- (void)startSession {
    if (self.isBackgrounded) return;
    if (self.session.isRunning && self.cameraReady) return;
    self.infoLabel.text = @"Starting camera…";
    self.cameraReady = NO;
    self.photoButton.enabled = NO;
    self.recordButton.enabled = NO;
    dispatch_async(self.cameraQueue, ^{
        [self.session stopRunning];
        NSError *error = nil;
        BOOL success = [self configureSession:&error];
        if (success && !self.isBackgrounded) [self.session startRunning];
        dispatch_async(dispatch_get_main_queue(), ^{
            self.cameraReady = success && self.session.isRunning && !self.isBackgrounded;
            self.photoButton.enabled = self.cameraReady;
            self.recordButton.enabled = self.cameraReady;
            self.infoLabel.text = self.cameraReady ? @"Capture runs only while this screen is visible" :
                (error.localizedDescription ?: @"Unable to start camera on this device");
            [self updateRecordAppearance];
            if (self.cameraReady) [self performPendingActionIfReady];
        });
    });
}

- (BOOL)configureSession:(NSError **)error {
    [self.session beginConfiguration];
    for (AVCaptureInput *input in [self.session.inputs copy]) [self.session removeInput:input];
    for (AVCaptureOutput *output in [self.session.outputs copy]) [self.session removeOutput:output];

    NSString *preset = [self desiredPreset];
    self.session.sessionPreset = [self.session canSetSessionPreset:preset] ? preset : AVCaptureSessionPresetHigh;

    AVCaptureDevice *camera = [AVCaptureDevice defaultDeviceWithDeviceType:AVCaptureDeviceTypeBuiltInWideAngleCamera
                                                                 mediaType:AVMediaTypeVideo
                                                                  position:[self desiredCameraPosition]];
    if (!camera) {
        [self.session commitConfiguration];
        if (error) *error = [NSError errorWithDomain:@"RBx9Capture" code:100 userInfo:@{NSLocalizedDescriptionKey:@"No compatible camera found"}];
        return NO;
    }
    AVCaptureDeviceInput *videoInput = [AVCaptureDeviceInput deviceInputWithDevice:camera error:error];
    if (!videoInput || ![self.session canAddInput:videoInput]) {
        [self.session commitConfiguration];
        return NO;
    }
    [self.session addInput:videoInput];

    if ([AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeAudio] == AVAuthorizationStatusAuthorized) {
        AVCaptureDevice *mic = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeAudio];
        AVCaptureDeviceInput *audioInput = mic ? [AVCaptureDeviceInput deviceInputWithDevice:mic error:nil] : nil;
        if (audioInput && [self.session canAddInput:audioInput]) [self.session addInput:audioInput];
    }

    self.photoOutput = [AVCapturePhotoOutput new];
    self.movieOutput = [AVCaptureMovieFileOutput new];
    if (![self.session canAddOutput:self.photoOutput] || ![self.session canAddOutput:self.movieOutput]) {
        [self.session commitConfiguration];
        if (error) *error = [NSError errorWithDomain:@"RBx9Capture" code:101 userInfo:@{NSLocalizedDescriptionKey:@"Photo/video outputs cannot run together on this device"}];
        return NO;
    }
    [self.session addOutput:self.photoOutput];
    [self.session addOutput:self.movieOutput];
    [self.session commitConfiguration];

    NSInteger fps = [self desiredFPS];
    for (AVFrameRateRange *range in camera.activeFormat.videoSupportedFrameRateRanges) {
        if (range.minFrameRate <= fps && range.maxFrameRate >= fps) {
            NSError *lockError = nil;
            if ([camera lockForConfiguration:&lockError]) {
                camera.activeVideoMinFrameDuration = CMTimeMake(1, (int32_t)fps);
                camera.activeVideoMaxFrameDuration = CMTimeMake(1, (int32_t)fps);
                [camera unlockForConfiguration];
            }
            break;
        }
    }
    return YES;
}

- (void)updateSettingsButtons {
    NSInteger q = [[NSUserDefaults standardUserDefaults] integerForKey:kQualityKey];
    [self.qualityButton setTitle:(q == 2 ? @"4K" : (q == 0 ? @"720p" : @"1080p")) forState:UIControlStateNormal];
    [self.fpsButton setTitle:[NSString stringWithFormat:@"%ld FPS", (long)[self desiredFPS]] forState:UIControlStateNormal];
    [self.flipButton setTitle:([self desiredCameraPosition] == AVCaptureDevicePositionFront ? @"FRONT" : @"REAR") forState:UIControlStateNormal];
}

- (void)updateRecordAppearance {
    NSString *state = self.isRecording ? @"● RECORDING VIDEO" : (self.cameraReady ? @"● CAMERA ACTIVE" : @"CAMERA OFF");
    self.statusLabel.text = state;
    self.statusLabel.backgroundColor = self.isRecording ? [UIColor colorWithRed:0.86 green:0.09 blue:0.12 alpha:1] :
        (self.cameraReady ? [UIColor colorWithRed:0.71 green:0.28 blue:0.08 alpha:1] : [UIColor darkGrayColor]);
    [self.recordButton setTitle:(self.isRecording ? @"STOP VIDEO" : @"RECORD") forState:UIControlStateNormal];
    self.flipButton.enabled = !self.isRecording;
    self.qualityButton.enabled = !self.isRecording;
    self.fpsButton.enabled = !self.isRecording;
}

- (void)requestAction:(RBXRequestedAction)action {
    self.pendingAction = action;
    if (self.cameraReady && !self.isBackgrounded) [self performPendingActionIfReady];
}

- (void)performPendingActionIfReady {
    if (!self.cameraReady || self.pendingAction == RBXRequestedActionNone || self.isBackgrounded) return;
    RBXRequestedAction action = self.pendingAction;
    self.pendingAction = RBXRequestedActionNone;
    if (action == RBXRequestedActionPhoto) [self takePhotoTapped:nil];
    if (action == RBXRequestedActionVideo) [self recordTapped:nil];
}

- (void)takePhotoTapped:(id)sender {
    if (!self.cameraReady || self.isBackgrounded) return;
    self.infoLabel.text = @"Taking photo…";
    AVCapturePhotoSettings *settings = [AVCapturePhotoSettings photoSettings];
    [self.photoOutput capturePhotoWithSettings:settings delegate:self];
}

- (void)recordTapped:(id)sender {
    if (!self.cameraReady || self.isBackgrounded || self.isStopping) return;
    if (self.isRecording) {
        self.isStopping = YES;
        self.infoLabel.text = @"Finishing video…";
        dispatch_async(self.cameraQueue, ^{ if (self.movieOutput.isRecording) [self.movieOutput stopRecording]; });
        return;
    }
    self.isRecording = YES;
    [self updateRecordAppearance];
    self.infoLabel.text = @"Video recording in progress";
    NSString *filename = [NSString stringWithFormat:@"RBx9-%@.mov", [NSUUID UUID].UUIDString];
    NSURL *url = [NSURL fileURLWithPath:[NSTemporaryDirectory() stringByAppendingPathComponent:filename]];
    dispatch_async(self.cameraQueue, ^{ [self.movieOutput startRecordingToOutputFileURL:url recordingDelegate:self]; });
}

- (void)flipTapped:(id)sender {
    if (self.isRecording) return;
    BOOL front = [[NSUserDefaults standardUserDefaults] boolForKey:kPositionKey];
    [[NSUserDefaults standardUserDefaults] setBool:!front forKey:kPositionKey];
    [self updateSettingsButtons];
    [self startSession];
}

- (void)qualityTapped:(id)sender {
    if (self.isRecording) return;
    NSInteger next = ([[NSUserDefaults standardUserDefaults] integerForKey:kQualityKey] + 1) % 3;
    [[NSUserDefaults standardUserDefaults] setInteger:next forKey:kQualityKey];
    [self updateSettingsButtons];
    [self startSession];
}

- (void)fpsTapped:(id)sender {
    if (self.isRecording) return;
    NSInteger next = [self desiredFPS] == 30 ? 60 : 30;
    [[NSUserDefaults standardUserDefaults] setInteger:next forKey:kFPSKey];
    [self updateSettingsButtons];
    [self startSession];
}

- (void)photoOutput:(AVCapturePhotoOutput *)output didFinishProcessingPhoto:(AVCapturePhoto *)photo error:(NSError *)error {
    if (error) { [self showMessage:[NSString stringWithFormat:@"Photo failed: %@", error.localizedDescription]]; return; }
    NSData *data = [photo fileDataRepresentation];
    UIImage *image = data ? [UIImage imageWithData:data] : nil;
    if (!image) { [self showMessage:@"Photo data unavailable"]; return; }
    [self requestPhotosPermissionThen:^(BOOL allowed) {
        if (!allowed) { [self showMessage:@"Allow Photos access in Settings to save pictures"]; return; }
        [[PHPhotoLibrary sharedPhotoLibrary] performChanges:^{
            [PHAssetChangeRequest creationRequestForAssetFromImage:image];
        } completionHandler:^(BOOL success, NSError *saveError) {
            [self showMessage:(success ? @"Photo saved to Photos" :
                [NSString stringWithFormat:@"Save failed: %@", saveError.localizedDescription])];
        }];
    }];
}

- (void)captureOutput:(AVCaptureFileOutput *)output
 didFinishRecordingToOutputFileAtURL:(NSURL *)outputFileURL
      fromConnections:(NSArray<AVCaptureConnection *> *)connections
                error:(NSError *)error {
    dispatch_async(dispatch_get_main_queue(), ^{
        self.isRecording = NO;
        self.isStopping = NO;
        [self updateRecordAppearance];
    });
    if (error) { [self showMessage:[NSString stringWithFormat:@"Recording error: %@", error.localizedDescription]]; return; }
    [self requestPhotosPermissionThen:^(BOOL allowed) {
        if (!allowed) { [self showMessage:@"Video saved temporarily; allow Photos access before leaving app"]; return; }
        [[PHPhotoLibrary sharedPhotoLibrary] performChanges:^{
            [PHAssetChangeRequest creationRequestForAssetFromVideoAtFileURL:outputFileURL];
        } completionHandler:^(BOOL success, NSError *saveError) {
            if (success) [[NSFileManager defaultManager] removeItemAtURL:outputFileURL error:nil];
            [self showMessage:(success ? @"Video saved to Photos" :
                [NSString stringWithFormat:@"Video save failed: %@", saveError.localizedDescription])];
        }];
    }];
}

- (void)requestPhotosPermissionThen:(void (^)(BOOL allowed))completion {
    [PHPhotoLibrary requestAuthorizationForAccessLevel:PHAccessLevelAddOnly handler:^(PHAuthorizationStatus status) {
        completion(status == PHAuthorizationStatusAuthorized || status == PHAuthorizationStatusLimited);
    }];
}

- (void)showMessage:(NSString *)message {
    dispatch_async(dispatch_get_main_queue(), ^{ self.infoLabel.text = message; });
}

- (void)stopForBackground {
    self.isBackgrounded = YES;
    self.pendingAction = RBXRequestedActionNone;
    self.cameraReady = NO;
    self.photoButton.enabled = NO;
    self.recordButton.enabled = NO;
    if (self.isRecording && !self.isStopping) {
        self.isStopping = YES;
        dispatch_async(self.cameraQueue, ^{ if (self.movieOutput.isRecording) [self.movieOutput stopRecording]; });
    }
    dispatch_async(self.cameraQueue, ^{ [self.session stopRunning]; });
    [self updateRecordAppearance];
}
@end
