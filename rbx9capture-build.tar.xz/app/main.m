#import <UIKit/UIKit.h>
#import "RBXAppDelegate.h"
int main(int argc, char *argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([RBXAppDelegate class]));
    }
}
