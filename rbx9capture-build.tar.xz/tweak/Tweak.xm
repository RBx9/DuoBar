#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <objc/message.h>
#import <objc/runtime.h>

// Only opens our foreground capture app. No private camera-service hooks,
// recording suppression, or camera-indicator bypass is implemented.
static CFAbsoluteTime gLastUp = 0;
static CFAbsoluteTime gLastDown = 0;
static const CFTimeInterval kDoublePressMaxDelay = 0.43;

static BOOL RBXIsDefinitelyUnlocked(void) {
    Class klass = NSClassFromString(@"SBLockScreenManager");
    if (!klass || ![klass respondsToSelector:@selector(sharedInstance)]) return NO;
    id manager = ((id (*)(id, SEL))objc_msgSend)(klass, @selector(sharedInstance));
    if ([manager respondsToSelector:@selector(isUILocked)]) {
        return !((BOOL (*)(id, SEL))objc_msgSend)(manager, @selector(isUILocked));
    }
    if ([manager respondsToSelector:@selector(isLocked)]) {
        return !((BOOL (*)(id, SEL))objc_msgSend)(manager, @selector(isLocked));
    }
    // Fail closed on an unknown iOS lock-state API.
    return NO;
}

static void RBXLaunchCapture(NSString *action) {
    dispatch_async(dispatch_get_main_queue(), ^{
        if (!RBXIsDefinitelyUnlocked()) return;
        NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"rbx9capture://%@", action]];
        if (@available(iOS 10.0, *)) {
            [[UIApplication sharedApplication] openURL:url options:@{} completionHandler:^(BOOL success) {
                if (!success) NSLog(@"[RBx9 Capture] Could not open capture app; install the application first.");
            }];
        }
    });
}

static void RBXVolumePressed(BOOL increased) {
    // Preserve normal volume controls via %orig below. A double-press is
    // interpreted only while the phone is unlocked.
    CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
    CFAbsoluteTime *last = increased ? &gLastUp : &gLastDown;
    BOOL isDoubleTap = (*last > 0 && now - *last <= kDoublePressMaxDelay);
    *last = isDoubleTap ? 0 : now;
    if (isDoubleTap) RBXLaunchCapture(increased ? @"video" : @"photo");
}

%hook SBVolumeControl
- (void)increaseVolume {
    %orig;
    RBXVolumePressed(YES);
}
- (void)decreaseVolume {
    %orig;
    RBXVolumePressed(NO);
}
%end
